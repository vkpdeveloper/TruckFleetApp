const mongoose = require("mongoose");

const bookTruckSchema = new mongoose.Schema({
    bid_amount: {
        type: Number,
        required: true
    },
    amount_type: {
        type: String,
        required: true
    },
    negotiable: {
        type: String,
        required: true
    },
    uid: {
        type: String,
        required: true
    },
    date: {
        type: Date,
        required: true
    }
});

const bookTruck = mongoose.model("bookTruck", bookTruckSchema);

module.exports = bookTruck;