const mongoose = require("mongoose");

const fleetSchema = new mongoose.Schema({
    pickup_location: {
        type: String,
        required: true
    },
    drop_location: {
        type: String,
        required: true
    },
    truck_number: {
        type: Number,
        required: true
    },
    fleet_rate: {
        type: Number,
        required: true
    },
    fleet_documents: {
        type: String
    },
    fleet_capacity: {
        type: String
    },
    fleet_type: {
        type: String,
        required: true
    },
    date: {
        type: Date
    },
    uid: {
        type: Number,
        required: true
    }
});

const fleet = mongoose.model("fleet", fleetSchema);

module.exports = fleet;