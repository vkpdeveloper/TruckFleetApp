const mongoose = require("mongoose");

const bookLoadSchema = new mongoose.Schema({
    bid_amount: {
        type: Number,
        required: true
    },
    amount_type: {
        type: String,
        required: true
    },
    negotiable: {
        type: String,
        required: true
    },
    availability: {
        type: String,
        required: true
    },
    fid: {
        type: String,
        required: true
    },
    uid: {
        type: String,
        required: true
    }
});

const bookLoad = mongoose.model("bookLoad", bookLoadSchema);

module.exports = bookLoad;