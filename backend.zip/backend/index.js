const app = require("./serverApp");
const User = require("./models/user");
const Fleet = require("./models/fleet");
const Load = require("./models/load");
const otpLogin = require("./models/otpLogin");
const BookLoad = require("./models/bookLoad");
const BookTruck = require("./models/bookTruck");
const mongoose = require("mongoose");
const load = require("./models/load");
const fleet = require("./models/fleet");

mongoose.connect("mongodb://localhost:27017/shreem", { useUnifiedTopology: true, useNewUrlParser: true })

app.get("/", (req, res) => {
    res.send({
        success: "Server started running properly"
    })
});



app.post("/register", async(req, res) => {
    try {
        const { email, name, mobile, user_type } = req.body;
        const createUser = new User({
            email,
            name,
            mobile,
            user_type

        });
        const response = await createUser.save();
        res.send({
            success: true,
            result: "User registered successfully"
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
})

app.post("/add_fleet", async(req, res) => {
    try {
        const { pickup_location, drop_location, truck_number, fleet_rate, fleet_documents, fleet_capacity, fleet_type, date, uid } = req.body;
        const addFleet = new Fleet({
            pickup_location,
            drop_location,
            truck_number,
            fleet_rate,
            fleet_documents,
            fleet_capacity,
            fleet_type,
            date,
            uid
        });
        const response = await addFleet.save();
        res.send({
            success: true,
            result: "Fleet added successfully"
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
})

app.post("/add_load", async(req, res) => {
    try {
        const { pickup_location, drop_location, load_weight, load_rate, load_type, date } = req.body;
        const addLoad = new Load({
            pickup_location,
            drop_location,
            load_weight,
            load_rate,
            load_type,
            date,
        });
        const response = await addLoad.save();
        res.send({
            success: true,
            result: "Load added successfully"
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
})

app.post("/otp_login", async(req, res) => {
    try {
        const { mobile } = req.body;
        const otpLogin = new otpLogin({
            mobile
        });
        const response = await otpLogin.save();
        res.send({
            success: true,
            result: "Otp sent successfully"
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
})

app.post("/book_truck", async(req, res) => {
    try {
        const { bid_amount, amount_type, negotiable, uid, date } = req.body;
        const BookTruck = new BookTruck({
            bid_amount,
            amount_type,
            negotiable,
            uid,
            date
        });
        const response = await BookTruck.save();
        res.send({
            success: true,
            result: "Booked truck successfully"
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
})

app.post("/book_load", async(req, res) => {
    try {
        const { bid_amount, amount_type, negotiable, availability, fid, uid, date } = req.body;
        const BookLoad = new BookLoad({
            bid_amount,
            amount_type,
            negotiable,
            availability,
            fid,
            uid,
            date
        });
        const response = await BookLoad.save();
        res.send({
            success: true,
            result: "Booked Load successfully"
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
})

app.get("/get_load", async(req, res) => {
    try {
        const allLoads = await load.find({});
        res.send({
            data: allLoads
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
});

app.get("/get_fleet", async(req, res) => {
    try {
        const allFleet = await fleet.find({});
        res.send({
            data: allFleet
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
});

app.get("/get_load_by_user", async(req, res) => {
    const { uid } = req.headers;
    try {
        const allLoadsByUser = await load.find({
            uid: uid
        });
        res.send({
            data: allLoadsByUser
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
});

app.get("/get_fleet_by_user", async(req, res) => {
    const { uid } = req.headers;
    try {
        const allFleetbyUser = await fleet.find({
            uid: uid
        });
        res.send({
            data: allFleetbyUser
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
});

app.get("/get_bookLoad", async(req, res) => {
    const { uid } = req.headers;
    try {
        const allBookLoads = await BookLoad.find({
            uid: uid
        });
        res.send({
            data: allBookLoads
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
});

app.get("/get_bookTruck", async(req, res) => {
    const { uid } = req.headers;
    try {
        const allBookTruck = await BookTruck.find({
            uid: uid
        });
        res.send({
            data: allBookTruck
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
});

app.get("/get_bookTruck", async(req, res) => {
    const { uid } = req.headers;
    try {
        const allBookTruck = await BookTruck.find({
            uid: uid
        });
        res.send({
            data: allBookTruck
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
});

app.post('/edit_profile', async(req, res) => {
    const { uid, name, email } = req.headers;
    try {
        const editProfile = await User.updateOne({

            _id: uid
        }, {
            name: name,
            email: email
        });
        res.send({
            data: editProfile
        })
    } catch (e) {
        res.send({
            error: e.message
        })
    }
});

app.listen(3000);